# Git Container

**Prevent Git hosting services from tracking your visits to other websites**

This is a fork of [Facebook Container](https://github.com/mozilla/contain-facebook)

Git Container is an add-on you can install on Firefox to prevent Git hosting services from tracking your activity on other websites, so you can continue to use Git hosting services while protecting your privacy.
